<?php
/*
|--------------------------------------------------------------------------
| Aksi login
|--------------------------------------------------------------------------
*/

session_start();
extract($_POST);
include './konfig.php';
if(isset($_POST['submit'])){
	$user = $_POST['username'];
	$pass = $_POST['password'];
	$query = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username = '$user' AND password = '$pass' ") or die (mysqli_connect_error());
    while ($baris = mysqli_fetch_object($query)) {
		echo "$baris->username";
	}
	$numberOfRows = mysqli_num_rows($query);
	if ($numberOfRows == 0){}
	else if ($numberOfRows > 0){
		$wewnes = mysqli_query($koneksi,"SELECT * FROM tbl_user WHERE username = '$user' AND password = '$pass' ") or die (mysqli_connect_error());
		while ($row = mysqli_fetch_array($wewnes)) {
        $_SESSION['username'] = $row['username'];
        $_SESSION['id_user'] = $row['id_user'];
        $_SESSION['hak_akses'] = $row['hak_akses'];
        $_SESSION['grup'] = $row['grup'];
if ($row['hak_akses'] == "Dokter") {
            header("location:dokter.php?view=tampil_pasien_dokter");
        } elseif ($row['hak_akses'] == "Front Office") {
            header("location:front-office.php?view=tampil_pasien");
        } elseif ($row['hak_akses'] == "Departemen") {
            header("location:departemen.php?view=tampil_pasien");
        } else {
            echo '<script>href.location</script>';
            session_destroy();
        }
    }
}else{
    echo "<script>
	location.href='index.php?error=salah';
	</script>";
}
}
?>