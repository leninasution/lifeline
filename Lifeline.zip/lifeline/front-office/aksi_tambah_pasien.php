<?php

include '../konfig.php';
extract($_POST);
$query = "insert into tbl_pasien values(null,'$nama','$alamat', '$jenis_kelamin', '$no_telepon') ";
mysqli_query($koneksi,$query);   