<?php

include '../konfig.php';
extract($_POST);
$query = "insert into tbl_prj values(null,'$id_dokter','$id_pasien', '$departemen', curtime(), '$keluhan', null, '$biaya', '$bayar', null)";
mysqli_query($koneksi,$query); 