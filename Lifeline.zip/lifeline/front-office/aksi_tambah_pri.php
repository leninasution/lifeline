<?php
include '../konfig.php';
extract($_POST);
$query = "insert into tbl_pri values('','$id_pasien', '$ 	id_ruang', '$tanggal_checkin', '$tanggal_checkout', '$hari_menginap', '$diagnosa', '$biaya', '$bayar')";
mysqli_query($koneksi,$query); 
//$query = "insert into tbl_pri values(null,'23', '103', '2018-07-26', '2018-07-29', '3', 'Demam Tinggi', '360000', '5000')";
//if(!mysqli_query($koneksi,$query)){
//die('Error: '.mysql_error());
//}
//echo json_encode(array('success'=>'true'));
