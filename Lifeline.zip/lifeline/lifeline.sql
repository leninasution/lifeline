-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2018 at 04:20 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lifeline`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dokter`
--

CREATE TABLE `tbl_dokter` (
  `id_user` int(5) NOT NULL,
  `nama_dokter` varchar(30) NOT NULL,
  `departemen` varchar(30) NOT NULL,
  `jadwal_praktik` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_dokter`
--

INSERT INTO `tbl_dokter` (`id_user`, `nama_dokter`, `departemen`, `jadwal_praktik`) VALUES
(1001, 'Aris Winata, dr', 'Umum', 'Senin - Jum''at | 10.00 - 15.00'),
(1002, 'Reza Syahputra, dr.SpB', 'Gigi', 'Senin - Rabu | 13.00 - 15.00'),
(1003, 'Ari Sandi, dr.SpA', 'Anak', 'Selasa - Kamis | 09.00 - 12.00'),
(1004, 'Kim Taehyun, dr.SpPD', 'Kandungan', 'Senin - Kamis | 08.00 - 15.00'),
(1005, 'Bambang Sucipto, H.dr.SpB', 'THT', 'Jum''at | 08.00 - 15.00'),
(1006, 'Sinta Purnama, dr.SpOG', 'Kandungan', 'Rabu  - Kamis | 10.00 - 12.00'),
(1007, 'Wahyu Pradana, dr.SpS.Mkes', 'Syaraf', 'Senin - Kamis | 08.00 - 15.00'),
(1008, 'Dahniar R, Hj.dr.SpKK', 'Kulit dan Kelamin', 'Kamis  - Jum''at | 08.00 - 15.00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pasien`
--

CREATE TABLE `tbl_pasien` (
  `id_pasien` int(6) NOT NULL,
  `nama_pasien` varchar(30) NOT NULL,
  `alamat` varchar(40) NOT NULL,
  `jenis_kelamin` char(1) NOT NULL,
  `no_telepon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pasien`
--

INSERT INTO `tbl_pasien` (`id_pasien`, `nama_pasien`, `alamat`, `jenis_kelamin`, `no_telepon`) VALUES
(1, 'Leni Nasution', 'Medan', 'P', '085261881172'),
(2, 'Astrini Twi A.K', 'Klaten', 'P', '081325450021'),
(4, 'Putri Ayu Lestari', '.Janti', 'P', '085265654747'),
(5, 'Dahniar Ramadhani K', 'Kulon Progo', 'P', '082123235656'),
(6, 'Muhammad Taufik', 'Yogyakarta', 'L', '081369695858'),
(7, 'Rahmad Ramadhan', 'Janti', 'L', '082247478965'),
(8, 'Febrianto', 'Umbulharjo', 'L', '081332145632'),
(9, 'Aprila Bena Putra', 'Yogyakarta', 'L', '082113132654'),
(10, 'Ade Puspita Ningrum', 'Bantul', 'P', '081325450022'),
(11, 'Dana Nur Fiqi', 'Bantul', 'L', '081325450023'),
(12, 'Valentina Nurpuspita', 'Bantul', 'P', '081325450026'),
(13, 'Muhdi Pangestu', 'Padang', 'L', '081325450027'),
(14, 'Yuli Supriani', 'Lampung', 'P', '081325450028'),
(15, 'Marselinus Seran', 'Yogyakarta', 'L', '081325450029'),
(16, 'Candra kurniawan', 'Klaten', 'L', '081325450087'),
(17, 'Bian Yovieta W', 'Klaten', 'L', '081325450066'),
(18, 'Vita Ariyana', 'Yogyakarta', 'P', '081325450066'),
(19, 'Doni Yanuar K.P', 'Bantul', 'L', '081325450077'),
(20, 'Ulfa Nurfajri M', 'Yogyakarta', 'P', '081325450698'),
(21, 'Rahmi Nanda K.P', 'Bantul', 'P', '081325453658'),
(22, 'Randy Bayu', 'Kalimantan', 'L', '082247450063'),
(23, 'Dewi Irawati', 'Yogyakarta', 'P', '082269450021'),
(24, 'Mariana Elda', 'Jakarta', 'P', '081258655532'),
(25, 'Khiftian A.P', 'Yogyakarta', 'L', '085363621420'),
(26, 'Arga Widhialoka P', 'Sleman', 'L', '085287993360'),
(30, 'Arum Mawar', 'Kulon Progo', 'P', '082214141212'),
(31, 'Surya Wihandika', 'Sleman', 'L', '082232604136');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pri`
--

CREATE TABLE `tbl_pri` (
  `no_ri` int(8) NOT NULL,
  `id_pasien` int(6) NOT NULL,
  `id_ruang` int(3) NOT NULL,
  `tanggal_checkin` date NOT NULL,
  `tanggal_checkout` date NOT NULL,
  `hari_menginap` int(3) NOT NULL,
  `diagnosa` text NOT NULL,
  `biaya` int(12) NOT NULL,
  `bayar` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pri`
--

INSERT INTO `tbl_pri` (`no_ri`, `id_pasien`, `id_ruang`, `tanggal_checkin`, `tanggal_checkout`, `hari_menginap`, `diagnosa`, `biaya`, `bayar`) VALUES
(59, 14, 102, '2018-07-26', '2018-07-27', 1, 'Asam Urat', 220000, 200000),
(60, 24, 108, '2018-07-26', '2018-07-29', 3, 'Epilepsi (Ayan)', 360000, 360000),
(61, 4, 103, '2018-07-26', '2018-07-29', 3, 'Demam Berdarah', 459000, 441000),
(62, 2, 101, '2018-07-27', '2018-08-07', 11, 'Kanker', 4125000, 4125000),
(63, 12, 103, '2018-07-23', '2018-07-31', 8, 'Herpes genital', 1224000, 1224000),
(64, 21, 107, '2018-06-22', '2018-06-28', 6, 'Alveolar Osteitis', 882000, 882000),
(65, 22, 104, '2018-07-01', '2018-07-02', 1, 'Demam', 130000, 130000),
(66, 19, 102, '2018-07-03', '2018-07-06', 3, 'Flu', 660000, 600000),
(67, 31, 108, '2018-07-20', '2018-07-21', 1, 'Asma', 120000, 120000),
(68, 26, 106, '2018-07-27', '2018-07-28', 1, 'HIPERTENSI (DARAH TINGGI)', 200000, 100000),
(74, 8, 107, '2018-07-04', '2018-07-05', 1, 'Flu', 147000, 147000),
(75, 26, 103, '2018-07-26', '2018-07-29', 3, 'Demam Tinggi', 360000, 350000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prj`
--

CREATE TABLE `tbl_prj` (
  `no_rj` int(8) NOT NULL,
  `id_dokter` varchar(5) NOT NULL,
  `id_pasien` int(6) NOT NULL,
  `departemen` varchar(20) NOT NULL,
  `tanggal` datetime NOT NULL,
  `keluhan` varchar(255) NOT NULL,
  `diagnosa` varchar(255) DEFAULT NULL,
  `biaya` int(10) NOT NULL,
  `bayar` int(12) DEFAULT NULL,
  `tindakan` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_prj`
--

INSERT INTO `tbl_prj` (`no_rj`, `id_dokter`, `id_pasien`, `departemen`, `tanggal`, `keluhan`, `diagnosa`, `biaya`, `bayar`, `tindakan`) VALUES
(4, '1002', 16, 'Gigi', '2018-07-27 10:36:59', 'demam, bau mulut, gusi merah dan rasa tidak nyaman karena nanah', 'Abses Gigi\r\n', 160000, 100000, 'Beri Resep'),
(5, '1003', 14, 'Anak', '2018-07-27 10:36:07', 'tenggorokan sakit terasa gatal. Adanya dahak di saluran pernafasan', 'Batuk', 180000, 200000, 'Beri Resep'),
(7, '1001', 17, 'Umum', '2018-07-27 10:35:43', 'bersin-bersin, batuk, hidung berair, pilek, mata merah dan berair', 'Alergi Rinitis (radang hidung)', 150000, 100000, 'Rawat Inap'),
(8, '1003', 10, 'Anak', '2018-07-27 10:35:09', 'Mual-mual, Panas, Mencret', NULL, 180000, 180000, NULL),
(9, '1004', 14, 'Kandungan', '2018-07-27 10:34:30', 'Keluar Cairan kuning kental, Sekitar miss v akan terasa panas, gatal, nyeri tekan.', '\r\n\r\n\r\n\r\nRadang genitalia interna', 200000, 200000, 'Beri Resep'),
(10, '1008', 13, 'Kulit dan Kelamin', '2018-07-27 11:58:49', 'perubahan cairan, nyeri, atau sensasi panas', 'Klamidia', 300000, 300000, 'Beri Resep'),
(11, '1007', 11, 'Syaraf', '2018-07-27 12:00:51', 'Kerkeringat terlalu banyak, limbung, mata dan mulut kering, sulit buang air besar, disfungsi kandung kemih, disfungsi seksual.', 'Saraf otonom', 180000, 100000, 'Beri Resep'),
(12, '1007', 15, 'Syaraf', '2018-07-27 12:01:32', 'Kelemahan, atrofi otot (ukuran otot mengecil), otot berkedut, kelumpuhan.', 'Saraf motorik', 180000, 180000, 'Rawat Inap'),
(13, '1006', 20, 'Kandungan', '2018-07-27 12:03:37', 'Terasa panas dan gatal,\r\nSuhu badan dapat meningkat\r\nBagian luar terjadi pembengkakan ', 'VAGINITIS', 200000, 200000, 'Beri Resep'),
(14, '1001', 18, 'Umum', '2018-07-27 12:28:19', 'demam tinggi, pusing, mata merah, hidung berair dan sakit tenggorokan, bintik berwarna merah jambu pada kulit seluruh tubuh, bengkak di persendian, telinga dan leher', 'CAMPAK (RUBELLA)', 150000, 100000, 'Beri Resep'),
(15, '1002', 25, 'Gigi', '2018-07-27 12:05:57', 'gusi berdarah, bau mulut, gusi bengkak dan terasa sangat sakit', 'Gingivitis\r\n', 160000, 160000, 'Beri Resep'),
(16, '1008', 7, 'Kulit dan Kelamin', '2018-07-27 13:11:01', 'perdarahan genitalia, keputihan, dan rasa nyeri yang bisa disalahpahami sebagai gejala infeksi kandung kemih atau vagina', 'Gonore', 300000, 300000, 'Beri Resep'),
(17, '1005', 4, 'THT', '2018-07-28 14:02:13', 'Mimisan, Pusing', '\r\nSinusitis', 150000, 150000, 'Beri Resep'),
(18, '', 12, 'THT', '2018-07-29 11:44:32', 'Telinga berdengung', NULL, 150000, 150000, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resep`
--

CREATE TABLE `tbl_resep` (
  `id_resep` int(9) NOT NULL,
  `id_dokter` int(8) NOT NULL,
  `id_pasien` varchar(2) NOT NULL,
  `nama_resep` varchar(50) NOT NULL,
  `rincian_resep` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_resep`
--

INSERT INTO `tbl_resep` (`id_resep`, `id_dokter`, `id_pasien`, `nama_resep`, `rincian_resep`, `tanggal`) VALUES
(11, 1008, '3', 'Sianida', 'Flu', '2018-06-25 22:27:24'),
(13, 1006, '13', 'Sariawan', 'Parasetamol', '2018-07-02 23:28:02'),
(14, 1002, '19', 'demam', 'parasetamol', '2018-07-28 00:51:06'),
(15, 1004, '14', 'Radang Genitalia', 'antibiotika golongan cefadroxyl 500 mg, diminum 3Ã—1 sesudah makan, selama sedikitnya 5-7 hari, dan asam mefenamat 500 mg', '2018-07-27 23:17:31'),
(17, 1002, '16', 'Abses Gigi', 'Parasetamol', '2018-07-28 00:45:26'),
(18, 1001, '18', 'CAMPAK (RUBELLA)', 'Qnc Jelly Gamat', '2018-07-28 00:59:47'),
(19, 1005, '4', 'Sinusitis', 'LEVOFLOXACIN 500MG\r\nFLUDEXIN SYR 60ML', '2018-07-29 02:15:02'),
(22, 0, '18', 'Diare', 'Entronstop', '2018-07-30 00:12:56'),
(23, 1004, '8', 'Diare', 'Entronstop', '2018-07-30 00:14:51'),
(24, 1004, '21', 'Demam', 'Bodrex', '2018-07-30 00:26:56');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tarif_ri`
--

CREATE TABLE `tbl_tarif_ri` (
  `id_tarif_ri` int(4) NOT NULL,
  `perawatan` varchar(20) NOT NULL,
  `pelayanan` varchar(30) NOT NULL,
  `tipe_kamar` varchar(20) NOT NULL,
  `tarif` int(8) NOT NULL,
  `kapasitas` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tarif_ri`
--

INSERT INTO `tbl_tarif_ri` (`id_tarif_ri`, `perawatan`, `pelayanan`, `tipe_kamar`, `tarif`, `kapasitas`) VALUES
(101, 'Rawat Inap per hari', 'Dokter Spesials dan Umum', 'Kelas VIP', 375000, 1),
(102, 'Rawat Inap per hari', 'Dokter Spesials dan Umum', 'Kelas I', 220000, 2),
(103, 'Rawat Inap per hari', 'Dokter Spesials dan Umum', 'Kelas II', 153000, 3),
(104, 'Rawat Inap per hari', 'Dokter Spesials dan Umum', 'Kelas III', 130000, 6),
(105, 'Rawat Inap per hari', 'Dokter Umum', 'Kelas VIP', 325000, 1),
(106, 'Rawat Inap per hari', 'Dokter Umum', 'Kelas I', 200000, 2),
(107, 'Rawat Inap per hari', 'Dokter Umum', 'Kelas II', 147000, 3),
(108, 'Rawat Inap per hari', 'Dokter Umum', 'Kelas III', 120000, 6),
(109, 'Ruang ICU', 'Dokter Spesials dan Umum', 'kelas VIP', 200000, 2),
(110, 'Ruang ICU', 'Dokter Umum', 'kelas VIP', 180000, 2),
(111, 'Ruang ICU', 'Instalasi  Anestesi', 'Kelas I', 217000, 2),
(112, 'Ruang ICU', 'Instalasi  Anestesi', 'Kelas II', 170000, 3),
(113, 'Ruang ICU', 'Instalasi  Anestesi', 'Kelas III', 136000, 6),
(114, 'Perinatologi', 'Dokter Spesialis dan Umum', 'Kelas VIP', 225000, 1),
(115, 'Perinatologi', 'Dokter Spesialis dan Umum', 'Kelas I', 192000, 2),
(116, 'Perinatologi', 'Dokter Spesialis dan Umum', 'Kelas II', 130000, 3),
(117, 'Perinatologi', 'Dokter Spesialis dan Umum', 'Kelas III', 130000, 6),
(118, 'Perinatologi', 'Dokter Umum', 'Kelas VIP', 200000, 1),
(119, 'Perinatologi', 'Dokter Umum', 'Kelas I', 172000, 2),
(120, 'Perinatologi', 'Dokter Umum', 'Kelas II', 130000, 3),
(121, 'Perinatologi', 'Dokter Umum', 'Kelas III', 120000, 6),
(122, 'Perinatologi', 'Gizi Rawat Inap', 'Kelas VIP', 120000, 1),
(123, 'Perinatologi', 'Gizi Rawat Inap', 'Kelas I', 100000, 2),
(124, 'Perinatologi', 'Gizi Rawat Inap', 'Kelas II', 70000, 3),
(126, 'Perinatologi', 'Persalinan Normal Dokter', 'Kelas VIP', 560000, 1),
(127, 'Perinatologi', 'Persalinan Normal Dokter', 'Kelas I', 470000, 2),
(128, 'Perinatologi', 'Persalinan Normal Dokter', 'Kelas II', 330000, 3),
(129, 'Perinatologi', 'Persalinan Normal Dokter', 'Kelas III', 270000, 6),
(130, 'Perinatologi', 'Persalinan Normal Bidan', 'Kelas VIP', 350000, 1),
(131, 'Perinatologi', 'Persalinan Normal Bidan', 'Kelas I', 300000, 2),
(132, 'Perinatologi', 'Persalinan Normal Bidan', 'Kelas II', 220000, 3),
(133, 'Perinatologi', 'Persalinan Normal Bidan', 'Kelas III', 190000, 6),
(134, 'Perinatologi', 'Persalinan Tidak Normal', 'Kelas VIP', 930000, 1),
(135, 'Perinatologi', 'Persalinan Tidak Normal', 'Kelas I', 750000, 2),
(136, 'Perinatologi', 'Persalinan Tidak Normal', 'Kelas II', 540000, 3),
(137, 'Perinatologi', 'Persalinan Tidak Normal', 'Kelas III', 470000, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tarif_rj`
--

CREATE TABLE `tbl_tarif_rj` (
  `id_tarif_rj` int(3) NOT NULL,
  `departemen` varchar(30) NOT NULL,
  `tarif` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tarif_rj`
--

INSERT INTO `tbl_tarif_rj` (`id_tarif_rj`, `departemen`, `tarif`) VALUES
(5, 'Umum', 150000),
(6, 'Gigi', 160000),
(7, 'Anak', 180000),
(8, 'Kandungan', 200000),
(9, 'THT', 150000),
(10, 'Syaraf', 180000),
(11, 'Kulit dan Kelamin', 300000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(5) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` int(1) NOT NULL,
  `hak_akses` varchar(20) NOT NULL,
  `grup` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `status`, `hak_akses`, `grup`) VALUES
(1, 'leni', 'leni', 0, 'Front Office', ''),
(2, 'dahniar', 'dahniar', 0, 'Departemen', 'Kandungan'),
(3, 'tht', 'tht', 0, 'Departemen', 'THT'),
(4, 'umum', 'umum', 0, 'Departemen', 'Umum'),
(5, 'anak', 'anak', 0, 'Departemen', 'Anak'),
(6, 'kulitkelamin', 'kulitkelamin', 0, 'Departemen', 'Kulit dan Kelamin'),
(7, 'syaraf', 'syaraf', 0, 'Departemen', 'Syaraf'),
(8, 'gigi', 'gigi', 0, 'Departemen', 'Gigi'),
(101, 'ari', 'ari', 0, 'Dokter', ' Ari Sandi, dr.SpA'),
(102, 'aris', 'aris', 0, 'Dokter', 'Aris Winata, dr'),
(103, 'reza', 'reza', 0, 'Dokter', 'Reza Syahputra, dr.SpB'),
(104, 'kim', 'kim', 0, 'Dokter', 'Kim Taehyun, dr.SpPD'),
(105, 'bambang', 'bambang', 0, 'Dokter', 'Bambang Sucipto, H.dr.SpB'),
(106, 'sinta', 'sinta', 0, 'Dokter', 'Sinta Purnama, dr.SpOG'),
(107, 'wahyu', 'wahyu', 0, 'Dokter', 'Wahyu Pradana, dr.SpS.Mkes'),
(108, 'dani', 'dani', 0, 'Dokter', 'Dahniar R, Hj.dr.SpKK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_dokter`
--
ALTER TABLE `tbl_dokter`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `tbl_pasien`
--
ALTER TABLE `tbl_pasien`
  ADD PRIMARY KEY (`id_pasien`);

--
-- Indexes for table `tbl_pri`
--
ALTER TABLE `tbl_pri`
  ADD PRIMARY KEY (`no_ri`);

--
-- Indexes for table `tbl_prj`
--
ALTER TABLE `tbl_prj`
  ADD PRIMARY KEY (`no_rj`),
  ADD KEY `id_pasien` (`id_pasien`);

--
-- Indexes for table `tbl_resep`
--
ALTER TABLE `tbl_resep`
  ADD PRIMARY KEY (`id_resep`);

--
-- Indexes for table `tbl_tarif_ri`
--
ALTER TABLE `tbl_tarif_ri`
  ADD PRIMARY KEY (`id_tarif_ri`);

--
-- Indexes for table `tbl_tarif_rj`
--
ALTER TABLE `tbl_tarif_rj`
  ADD PRIMARY KEY (`id_tarif_rj`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_dokter`
--
ALTER TABLE `tbl_dokter`
  MODIFY `id_user` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1009;
--
-- AUTO_INCREMENT for table `tbl_pasien`
--
ALTER TABLE `tbl_pasien`
  MODIFY `id_pasien` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `tbl_pri`
--
ALTER TABLE `tbl_pri`
  MODIFY `no_ri` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
--
-- AUTO_INCREMENT for table `tbl_prj`
--
ALTER TABLE `tbl_prj`
  MODIFY `no_rj` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `tbl_resep`
--
ALTER TABLE `tbl_resep`
  MODIFY `id_resep` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `tbl_tarif_ri`
--
ALTER TABLE `tbl_tarif_ri`
  MODIFY `id_tarif_ri` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;
--
-- AUTO_INCREMENT for table `tbl_tarif_rj`
--
ALTER TABLE `tbl_tarif_rj`
  MODIFY `id_tarif_rj` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_prj`
--
ALTER TABLE `tbl_prj`
  ADD CONSTRAINT `tbl_prj_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `tbl_pasien` (`id_pasien`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
