<?php
/*
|--------------------------------------------------------------------------
| Konfigurasi Database
|--------------------------------------------------------------------------
*/

	$server = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "lifeline";
        
    $base_url = "http://localhost/lifeline/";
	$koneksi = mysqli_connect($server,$user,$pass,$dbname);
	if(!$koneksi){
		die("Koneksi Gagal : ".mysqli_connect_error());
	}
	echo "Koneksi Berhasil";	 
?>